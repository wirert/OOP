﻿namespace _04.BorderControl
{
    public interface IIdentifiable
    {        
        public string Id { get; }
    }
}
